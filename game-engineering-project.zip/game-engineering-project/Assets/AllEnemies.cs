using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class EnemyAI : MonoBehaviour
{
    public Transform target;
    public float pathUpdateRate;

    [Header("Physics")]
    public float speed = 20f;
    public float jumpSpeed = 10f;
    public float nextPointDistance = 3f;
    public float jumpNodeHeight = 0.8f;


    private Path path;
    private int currentWaypoint = 0;
    bool grounded = false;
    bool roofed = false;
    Seeker seeker;
    Rigidbody2D rb;
    CircleCollider2D coll;

    public void Start(){
        seeker = GetComponent<Seeker>();
        rb = GetComponent<Rigidbody2D>();
        coll = GetComponent<CircleCollider2D>();

        InvokeRepeating("UpdatePath", 0f, pathUpdateRate);
    }

    private void FixedUpdate()
    {
        PathFollow();
    }

    private void UpdatePath(){
        if(seeker.IsDone()){
            seeker.StartPath(rb.position, target.position, OnPathComplete);
        }
    }    

    private void PathFollow(){
        if (path == null){
            return;
        }

        if (currentWaypoint >= path.vectorPath.Count){
            return;
        }

        //See if colliding with anything
        roofed = Physics2D.Raycast(coll.bounds.max, Vector2.up, 0.1f);
        grounded = Physics2D.Raycast(coll.bounds.min, Vector2.down, 0.1f);

        //Direction Calculation
        Vector2 direction = ((Vector2)path.vectorPath[currentWaypoint] - rb.position).normalized;
        Vector2 force = direction * speed ;
        force.y = 0;

        //Jump
        if (grounded){
            if(direction.y > jumpNodeHeight){
                rb.velocity = Vector2.up * jumpSpeed;
            }
        }

        //Inverse Jump
        if (roofed){
            if(direction.y < jumpNodeHeight){
                rb.velocity = Vector2.down * jumpSpeed;
            }
        }


        //Movement
        rb.AddForce(force);

        //Next Waypoint
        float distance = Vector2.Distance(rb.position, path.vectorPath[currentWaypoint]);
        if(distance < nextPointDistance){
            currentWaypoint++;
        }
    }

    private void OnPathComplete(Path p){
        if(!p.error){
            path = p;
            currentWaypoint = 0;
        }
    }
}
